var database;

var canvas;

var playerCount, gameState = 0;

var allPlayers;

var player, login, game;

var pokemon1, pokemon2, pokemon3, pokemon4, pokemon5, pokemons;
var addImages = true;

var font;

var bgImg;

const POKEMONS = ["Aegislash", "Articuno", "Bisharp", "Blastoise", "Celebi", "Chesnaught", 
"Cinderace", "Delphox", "Dragonite", "Entei", "Eternatus", "Garchomp", "Greninja", "Hawlucha", "Ho-Oh",
"Incineroar", "Inteleon", "Jirachi", "Litten", "Lucario", "Lugia", "Lycanroc_day", "Lycanroc_night",
"Magikarp", "Melmetal", "Mew", "Mewtwo", "Moltres", "Rayquaza", "Rillaboom",
"Sceptile", "Torracat","Tyranitar", "Wobbuffet", "Xerneas", "Yveltal", "Zapdos", "Zygarde",
"Bulbasaur", "Ivysaur", "Venusaur", "Mega-Venusaur", "Venusaur_Gigamax", "Charmander", "Charmeleon", 
"Charizard", "Mega-Charizard_X", "Mega-Charizard_Y", "Charizard_Gigamax", "Squirtle", "Wartortle",
"Blastoise", "Mega-Blastoise", "Blastoise_Gigamax", "Caterpie", "Metapod", "Butterfree", 
"Butterfree_Gigamax", "Weedle","Kakuna", "Beedrill", "Mega-Beedrill", "Pidgey", "Pidgeotto", "Pidgeot",
"Mega-Pidgeot", "Rattata", "Rattata_de_Alola", "Raticate", "Raticate_de_Alola", "Spearow", "Fearow",
"Ekans", "Arbok", "Pichu","Pikachu", "Pikachu_Gigamax", "Raichu", "Raichu_de_Alola", "Sandshrew", 
"Sandshrew_de_Alola", "Sandslash", "Sandslash_de_Alola", "Nidoran_Female", "Nidorina", "Nidoqueen",
"Nidoran_Male", "Nidorino", "Nidoking", "Cleffa", "Clefairy", "Clefable", "Igglybuff", "Jigglypuff",
"Wigglytuff", "Zubat", "Golbat", "Crobat", "Oddish", "Gloom", "Vileplume", "Paras", "Parasect",
"Venonat", "Venomoth", "Diglett", "Diglett_de_Alola", "Dugtrio", "Dugtrio_de_Alola", "Meowth",
"Meowth_de_Alola", "Meowth_de_Galar", "Meowth_Gigamax", "Persian", "Persian_de_Alola",
"Psyduck", "Golduck", "Mankey", "Primeape", "Growlithe", "Arcanine", "Poliwag", "Poliwhirl",
"Poliwrath", "Abra", "Kadabra", "Alakazam", "Mega-Alakazam", "Machop", "Machoke", "Machamp",
"Machamp_Gigamax"];
var p1Img, p2Img, p3Img, p4Img, p5Img;
var pokemonsAtEnd = 0;

var trackPos = 0;

var winSound;
var notPlayed = true;
function preload() {
    font = loadFont("fonts/Ultra Fresh.ttf");
    bgImg = loadImage("images/bg/track.png");
    winSound = loadSound("Audio/Win.mp3");
}
function setup() {
    database = firebase.database();
    canvas = createCanvas(window.innerWidth - 25, window.innerHeight - 25);
    game = new Game();
    game.start();
    console.log(POKEMONS.length);
}
function draw() {
    game.getState();
    if (gameState === 0) {
        background("yellow");
    }
    if (playerCount >= 5 && gameState !== 2) {
        game.update(1);
    }
    if (gameState === 1) {
        background("#0000FF");
        game.play();
    }
    if (gameState === 2) {
       game.end();
    }
}
function touchEnded() {
    touches = [];
}